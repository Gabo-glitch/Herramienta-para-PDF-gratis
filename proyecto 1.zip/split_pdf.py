from PyPDF2 import PdfReader, PdfWriter
def split_pdf(inp,out,page):
    r=PdfReader(inp)
    w=PdfWriter()
    w.add_page(r.pages[page-1])
    with open(out,"wb") as f:
        w.write(f)
