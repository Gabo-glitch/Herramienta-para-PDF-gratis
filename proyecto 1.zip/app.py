from flask import Flask, render_template, request, send_file
import os
from converters.compress_pdf import compress_pdf
from converters.pdf_to_word import pdf_to_word
from converters.word_to_pdf import word_to_pdf
from converters.merge_pdf import merge_pdf
from converters.split_pdf import split_pdf

app = Flask(__name__)
UPLOAD_FOLDER="uploads"
PROCESSED_FOLDER="processed"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PROCESSED_FOLDER, exist_ok=True)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/compress", methods=["POST"])
def compress():
    file=request.files["file"]
    path=os.path.join(UPLOAD_FOLDER,file.filename)
    file.save(path)
    out=os.path.join(PROCESSED_FOLDER,"compressed_"+file.filename)
    compress_pdf(path,out)
    return send_file(out, as_attachment=True)

@app.route("/pdf_to_word", methods=["POST"])
def pdfToWord():
    file=request.files["file"]
    path=os.path.join(UPLOAD_FOLDER,file.filename)
    file.save(path)
    out=os.path.join(PROCESSED_FOLDER,file.filename.replace(".pdf",".docx"))
    pdf_to_word(path,out)
    return send_file(out, as_attachment=True)

@app.route("/word_to_pdf", methods=["POST"])
def wordToPdf():
    file=request.files["file"]
    path=os.path.join(UPLOAD_FOLDER,file.filename)
    file.save(path)
    out=os.path.join(PROCESSED_FOLDER,file.filename.replace(".docx",".pdf"))
    word_to_pdf(path,out)
    return send_file(out, as_attachment=True)

@app.route("/merge", methods=["POST"])
def merge():
    files=request.files.getlist("files")
    paths=[]
    for f in files:
        p=os.path.join(UPLOAD_FOLDER,f.filename)
        f.save(p)
        paths.append(p)
    out=os.path.join(PROCESSED_FOLDER,"merged.pdf")
    merge_pdf(paths,out)
    return send_file(out, as_attachment=True)

@app.route("/split", methods=["POST"])
def splitRoute():
    file=request.files["file"]
    page=request.form.get("page")
    page=int(page)
    path=os.path.join(UPLOAD_FOLDER,file.filename)
    file.save(path)
    out=os.path.join(PROCESSED_FOLDER,f"split_page_{page}.pdf")
    split_pdf(path,out,page)
    return send_file(out, as_attachment=True)

if __name__=="__main__":
    app.run(debug=True)
