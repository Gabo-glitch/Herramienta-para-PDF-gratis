from pdf2docx import Converter
def pdf_to_word(a,b):
    cv=Converter(a); cv.convert(b); cv.close()
