from docx2pdf import convert
def word_to_pdf(a,b):
    convert(a,b)
