from PyPDF2 import PdfMerger
def merge_pdf(paths,out):
    merger=PdfMerger()
    for p in paths:
        merger.append(p)
    merger.write(out)
    merger.close()
