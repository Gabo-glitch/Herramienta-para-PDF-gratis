import pikepdf
def compress_pdf(inp,out):
    pdf=pikepdf.Pdf.open(inp)
    pdf.save(out,compression=pikepdf.CompressionLevel.compression_medium)
